package junit.runner;
public class Version {
    public static String id() {
        return "4.13-SNAPSHOT";
    }
    public static void main ( final String[] args ) {
        System.out.println ( id() );
    }
}
