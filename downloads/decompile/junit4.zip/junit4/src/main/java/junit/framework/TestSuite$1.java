package junit.framework;
static final class TestSuite$1 extends TestCase {
    final   String val$message;
    protected void runTest() {
        TestCase.fail ( this.val$message );
    }
}
