package org.junit.runners.parameterized;
private enum InjectionType {
    CONSTRUCTOR,
    FIELD;
}
