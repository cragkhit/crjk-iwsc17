package org.junit.experimental.max;
static class MaxHistory$1 {}
