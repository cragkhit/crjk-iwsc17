package org.junit.internal.runners.rules;
static class RuleMemberValidator$1 {}
