package org.junit.internal;
static final class ComparisonCriteria$1 {
    final   String val$string;
    public String toString() {
        return this.val$string;
    }
}
