package org.junit.internal.runners;
class MethodRoadie$2 implements Runnable {
    public void run() {
        MethodRoadie.this.runTestMethod();
    }
}
