package org.junit.rules;
static class Stopwatch$1 {}
