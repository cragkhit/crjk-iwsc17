package org.junit.runner;
static class Result$1 {}
