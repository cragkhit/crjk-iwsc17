package org.junit.internal.runners;
static class JUnit38ClassRunner$1 {}
