package org.junit.validator;
static class AnnotationsValidator$1 {}
