package org.junit.internal.requests;
static class ClassRequest$1 {}
