package org.junit.experimental.max;
public class CouldNotReadCoreException extends Exception {
    private static final long serialVersionUID = 1L;
    public CouldNotReadCoreException ( final Throwable e ) {
        super ( e );
    }
}
