package org.junit.runner.manipulation;
import org.junit.runner.Description;
import java.util.Comparator;
static final class Sorter$1 implements Comparator<Description> {
    public int compare ( final Description o1, final Description o2 ) {
        return 0;
    }
}
