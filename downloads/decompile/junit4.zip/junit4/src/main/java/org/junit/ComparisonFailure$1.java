package org.junit;
static class ComparisonFailure$1 {}
