package org.junit;
public static class None extends Throwable {
    private static final long serialVersionUID = 1L;
}
