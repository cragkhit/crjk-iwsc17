package org.junit.internal.runners.statements;
static class FailOnTimeout$1 {}
