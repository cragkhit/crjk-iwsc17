package org.junit.experimental.max;
import org.junit.runner.Runner;
import java.util.List;
import org.junit.runners.Suite;
class MaxCore$1$1 extends Suite {}
