package org.junit.internal.runners;
import java.util.concurrent.Callable;
class MethodRoadie$1$1 implements Callable<Object> {
    public Object call() throws Exception {
        Runnable.this.this$0.runTestMethod();
        return null;
    }
}
