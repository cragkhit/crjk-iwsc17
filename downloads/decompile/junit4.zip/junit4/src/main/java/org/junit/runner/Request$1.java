package org.junit.runner;
static final class Request$1 extends Request {
    final   Runner val$runner;
    public Runner getRunner() {
        return this.val$runner;
    }
}
