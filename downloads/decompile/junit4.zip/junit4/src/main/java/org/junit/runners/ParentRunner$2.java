package org.junit.runners;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.Statement;
class ParentRunner$2 extends Statement {
    final   RunNotifier val$notifier;
    public void evaluate() {
        ParentRunner.access$000 ( ParentRunner.this, this.val$notifier );
    }
}
