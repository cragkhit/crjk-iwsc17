package org.junit.experimental.theories.internal;
static class AllMembersSupplier$1 {}
