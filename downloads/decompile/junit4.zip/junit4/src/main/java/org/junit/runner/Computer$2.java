package org.junit.runner;
import org.junit.runners.model.RunnerBuilder;
import org.junit.runners.Suite;
class Computer$2 extends Suite {
    protected String getName() {
        return "classes";
    }
}
