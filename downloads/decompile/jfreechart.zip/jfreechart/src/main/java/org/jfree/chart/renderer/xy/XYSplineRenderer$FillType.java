package org.jfree.chart.renderer.xy;
public enum FillType {
    NONE,
    TO_ZERO,
    TO_LOWER_BOUND,
    TO_UPPER_BOUND;
}
