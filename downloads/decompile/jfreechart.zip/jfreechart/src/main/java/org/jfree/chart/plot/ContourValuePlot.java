package org.jfree.chart.plot;
import org.jfree.data.Range;
public interface ContourValuePlot {
    Range getContourDataRange();
}
