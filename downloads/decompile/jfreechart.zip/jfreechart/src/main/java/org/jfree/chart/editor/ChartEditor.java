package org.jfree.chart.editor;
import org.jfree.chart.JFreeChart;
public interface ChartEditor {
    void updateChart ( JFreeChart p0 );
}
