package org.jfree.data.function;
public interface Function2D {
    double getValue ( double p0 );
}
