package org.jfree.chart.event;
import java.util.EventListener;
public interface MarkerChangeListener extends EventListener {
    void markerChanged ( MarkerChangeEvent p0 );
}
