package org.jfree.chart.event;
import java.util.EventListener;
public interface AnnotationChangeListener extends EventListener {
    void annotationChanged ( AnnotationChangeEvent p0 );
}
