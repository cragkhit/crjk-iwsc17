package org.jfree.data.general;
private class DatasetInfo {
    private SeriesDataset data;
    private int series;
    DatasetInfo ( final SeriesDataset data, final int series ) {
        this.data = data;
        this.series = series;
    }
}
