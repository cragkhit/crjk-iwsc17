package org.jfree.chart;
public interface ChartTheme {
    void apply ( JFreeChart p0 );
}
