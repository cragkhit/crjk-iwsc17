package org.jfree.chart.labels;
import org.jfree.data.category.CategoryDataset;
public interface CategorySeriesLabelGenerator {
    String generateLabel ( CategoryDataset p0, int p1 );
}
