package org.jfree.chart.event;
import java.util.EventListener;
public interface ChartChangeListener extends EventListener {
    void chartChanged ( ChartChangeEvent p0 );
}
