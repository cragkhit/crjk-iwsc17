package org.jfree.data.category;
import org.jfree.data.general.Dataset;
import org.jfree.data.KeyedValues2D;
public interface CategoryDataset extends KeyedValues2D, Dataset {
}
