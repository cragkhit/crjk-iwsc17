package org.jfree.chart.block;
public interface EntityBlockParams {
    boolean getGenerateEntities();
}
