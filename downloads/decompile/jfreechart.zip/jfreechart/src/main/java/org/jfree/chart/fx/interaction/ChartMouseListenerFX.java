package org.jfree.chart.fx.interaction;
public interface ChartMouseListenerFX {
    void chartMouseClicked ( ChartMouseEventFX p0 );
    void chartMouseMoved ( ChartMouseEventFX p0 );
}
