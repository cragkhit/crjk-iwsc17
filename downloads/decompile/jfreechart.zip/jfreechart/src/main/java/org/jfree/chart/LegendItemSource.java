package org.jfree.chart;
public interface LegendItemSource {
    LegendItemCollection getLegendItems();
}
