package org.jfree.chart.encoders;
public interface ImageFormat {
    public static final String PNG = "png";
    public static final String JPEG = "jpeg";
    public static final String GIF = "gif";
}
