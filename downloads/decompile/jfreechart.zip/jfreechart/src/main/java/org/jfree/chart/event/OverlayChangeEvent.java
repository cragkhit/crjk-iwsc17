package org.jfree.chart.event;
import java.util.EventObject;
public class OverlayChangeEvent extends EventObject {
    public OverlayChangeEvent ( final Object source ) {
        super ( source );
    }
}
