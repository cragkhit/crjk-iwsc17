package org.jfree.chart.plot.dial;
import java.util.EventListener;
public interface DialLayerChangeListener extends EventListener {
    void dialLayerChanged ( DialLayerChangeEvent p0 );
}
