package org.jfree.chart.event;
import java.util.EventListener;
public interface PlotChangeListener extends EventListener {
    void plotChanged ( PlotChangeEvent p0 );
}
