package org.jfree.chart.labels;
import org.jfree.chart.plot.Crosshair;
public interface CrosshairLabelGenerator {
    String generateLabel ( Crosshair p0 );
}
