package org.jfree.chart.event;
import java.util.EventListener;
public interface AxisChangeListener extends EventListener {
    void axisChanged ( AxisChangeEvent p0 );
}
