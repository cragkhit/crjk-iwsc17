package org.jfree.chart.plot;
public class XYCrosshairState extends CrosshairState {
}
