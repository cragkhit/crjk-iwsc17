package org.jfree.chart.event;
import java.util.EventListener;
public interface TitleChangeListener extends EventListener {
    void titleChanged ( TitleChangeEvent p0 );
}
