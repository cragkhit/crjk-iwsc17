package org.jfree.chart.imagemap;
public interface ToolTipTagFragmentGenerator {
    String generateToolTipFragment ( String p0 );
}
