package org.jfree.chart.event;
import java.util.EventListener;
public interface ChartProgressListener extends EventListener {
    void chartProgress ( ChartProgressEvent p0 );
}
