package org.jfree.chart.plot;
import org.jfree.data.Range;
import org.jfree.chart.axis.ValueAxis;
public interface ValueAxisPlot {
    Range getDataRange ( ValueAxis p0 );
}
