package org.jfree.chart.labels;
import org.jfree.data.contour.ContourDataset;
public interface ContourToolTipGenerator {
    String generateToolTip ( ContourDataset p0, int p1 );
}
