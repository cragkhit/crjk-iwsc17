package org.jfree.chart.urls;
import org.jfree.data.category.CategoryDataset;
public interface CategoryURLGenerator {
    String generateURL ( CategoryDataset p0, int p1, int p2 );
}
