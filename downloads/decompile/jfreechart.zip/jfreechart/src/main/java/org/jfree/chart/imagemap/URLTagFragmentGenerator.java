package org.jfree.chart.imagemap;
public interface URLTagFragmentGenerator {
    String generateURLFragment ( String p0 );
}
