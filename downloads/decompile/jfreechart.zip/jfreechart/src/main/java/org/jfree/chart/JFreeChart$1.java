package org.jfree.chart;
import java.awt.RenderingHints;
static final class JFreeChart$1 extends RenderingHints.Key {
    @Override
    public boolean isCompatibleValue ( final Object val ) {
        return val instanceof Boolean;
    }
}
