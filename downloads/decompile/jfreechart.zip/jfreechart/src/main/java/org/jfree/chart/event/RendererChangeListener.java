package org.jfree.chart.event;
import java.util.EventListener;
public interface RendererChangeListener extends EventListener {
    void rendererChanged ( RendererChangeEvent p0 );
}
