package org.jfree.chart.axis;
static class DateAxis$1 {}
