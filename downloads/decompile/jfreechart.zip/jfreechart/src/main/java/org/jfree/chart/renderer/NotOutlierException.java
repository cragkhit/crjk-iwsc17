package org.jfree.chart.renderer;
public class NotOutlierException extends Exception {
    public NotOutlierException ( final String message ) {
        super ( message );
    }
}
