package org.jfree.chart.labels;
import org.jfree.data.xy.XYDataset;
public interface XYToolTipGenerator {
    String generateToolTip ( XYDataset p0, int p1, int p2 );
}
