package org.jfree.chart.block;
import org.jfree.chart.entity.EntityCollection;
public interface EntityBlockResult {
    EntityCollection getEntityCollection();
}
