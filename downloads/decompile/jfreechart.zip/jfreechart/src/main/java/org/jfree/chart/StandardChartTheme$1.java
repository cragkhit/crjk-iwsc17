package org.jfree.chart;
static final class StandardChartTheme$1 extends StandardChartTheme {
    @Override
    public void apply ( final JFreeChart chart ) {
    }
}
