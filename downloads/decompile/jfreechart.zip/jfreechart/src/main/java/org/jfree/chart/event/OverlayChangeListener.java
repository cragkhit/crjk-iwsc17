package org.jfree.chart.event;
import java.util.EventListener;
public interface OverlayChangeListener extends EventListener {
    void overlayChanged ( OverlayChangeEvent p0 );
}
