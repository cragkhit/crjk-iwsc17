package org.jfree.chart.axis;
protected class BaseTimelineSegmentRange extends SegmentRange {
    public BaseTimelineSegmentRange ( final long fromDomainValue, final long toDomainValue ) {
        super ( fromDomainValue, toDomainValue );
    }
}
