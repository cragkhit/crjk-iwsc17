package org.jfree.data.category;
import org.jfree.data.Range;
import java.util.List;
public interface CategoryRangeInfo {
    Range getRangeBounds ( List p0, boolean p1 );
}
