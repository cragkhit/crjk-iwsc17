package org.jfree.chart;
public interface Effect3D {
    double getXOffset();
    double getYOffset();
}
