package org.jfree.chart.urls;
import org.jfree.data.general.PieDataset;
public interface PieURLGenerator {
    String generateURL ( PieDataset p0, Comparable p1, int p2 );
}
