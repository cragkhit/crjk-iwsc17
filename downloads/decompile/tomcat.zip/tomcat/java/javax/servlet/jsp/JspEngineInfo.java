package javax.servlet.jsp;
public abstract class JspEngineInfo {
    public abstract String getSpecificationVersion();
}
