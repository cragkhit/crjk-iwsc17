package javax.servlet.jsp.el;
public interface VariableResolver {
    Object resolveVariable ( String p0 ) throws ELException;
}
