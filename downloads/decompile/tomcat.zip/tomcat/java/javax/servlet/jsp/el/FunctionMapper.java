package javax.servlet.jsp.el;
import java.lang.reflect.Method;
public interface FunctionMapper {
    Method resolveFunction ( String p0, String p1 );
}
