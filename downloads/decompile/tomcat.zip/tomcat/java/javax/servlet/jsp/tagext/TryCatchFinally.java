package javax.servlet.jsp.tagext;
public interface TryCatchFinally {
    void doCatch ( Throwable p0 ) throws Throwable;
    void doFinally();
}
