package javax.servlet.jsp.tagext;
public interface JspTag {
}
