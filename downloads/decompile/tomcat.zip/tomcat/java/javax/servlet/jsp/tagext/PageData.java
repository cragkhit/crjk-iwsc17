package javax.servlet.jsp.tagext;
import java.io.InputStream;
public abstract class PageData {
    public abstract InputStream getInputStream();
}
