package javax.servlet.jsp.tagext;
import javax.servlet.jsp.JspException;
public interface DynamicAttributes {
    void setDynamicAttribute ( String p0, String p1, Object p2 ) throws JspException;
}
