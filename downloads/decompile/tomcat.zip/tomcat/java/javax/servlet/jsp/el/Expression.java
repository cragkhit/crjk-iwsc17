package javax.servlet.jsp.el;
public abstract class Expression {
    public abstract Object evaluate ( final VariableResolver p0 ) throws ELException;
}
