package javax.servlet.jsp.tagext;
public interface JspIdConsumer {
    void setJspId ( String p0 );
}
