package javax.servlet;
public interface Dynamic extends Registration {
    void setAsyncSupported ( boolean p0 );
}
