package javax.servlet;
public interface Dynamic extends FilterRegistration, Registration.Dynamic {
}
