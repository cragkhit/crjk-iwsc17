package javax.servlet.annotation;
public enum TransportGuarantee {
    NONE,
    CONFIDENTIAL;
}
