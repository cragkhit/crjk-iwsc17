package javax.servlet.annotation;
public enum EmptyRoleSemantic {
    PERMIT,
    DENY;
}
