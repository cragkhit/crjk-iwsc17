package javax.servlet.http;
class HttpServletRequest$1 implements Mapping {
    @Override
    public String getMatchValue() {
        return "";
    }
    @Override
    public String getPattern() {
        return "";
    }
    @Override
    public MappingMatch getMappingMatch() {
        return MappingMatch.UNKNOWN;
    }
    @Override
    public String getServletName() {
        return "";
    }
}
