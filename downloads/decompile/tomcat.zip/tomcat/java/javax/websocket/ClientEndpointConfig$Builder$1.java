package javax.websocket;
static final class ClientEndpointConfig$Builder$1 extends Configurator {}
