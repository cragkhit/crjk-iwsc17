package javax.websocket;
public interface CloseCode {
    int getCode();
}
