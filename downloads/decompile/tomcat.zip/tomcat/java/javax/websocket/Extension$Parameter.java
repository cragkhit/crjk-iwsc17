package javax.websocket;
public interface Parameter {
    String getName();
    String getValue();
}
