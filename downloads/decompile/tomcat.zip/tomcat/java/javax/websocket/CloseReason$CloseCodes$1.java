package javax.websocket;
static final class CloseReason$CloseCodes$1 implements CloseCode {
    final   int val$code;
    @Override
    public int getCode() {
        return this.val$code;
    }
}
