package javax.websocket;
import java.util.List;
import java.util.Map;
public static class Configurator {
    public void beforeRequest ( final Map<String, List<String>> headers ) {
    }
    public void afterResponse ( final HandshakeResponse handshakeResponse ) {
    }
}
