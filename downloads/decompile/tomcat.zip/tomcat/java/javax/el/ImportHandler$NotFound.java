package javax.el;
private static class NotFound {
}
