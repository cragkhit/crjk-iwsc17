package javax.el;
import java.security.PrivilegedAction;
static final class ExpressionFactory$3 implements PrivilegedAction<String> {
    @Override
    public String run() {
        return ExpressionFactory.access$100();
    }
}
