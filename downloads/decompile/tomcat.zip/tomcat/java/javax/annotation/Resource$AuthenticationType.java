package javax.annotation;
public enum AuthenticationType {
    CONTAINER,
    APPLICATION;
}
