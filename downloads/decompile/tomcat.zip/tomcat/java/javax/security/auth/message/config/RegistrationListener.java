package javax.security.auth.message.config;
public interface RegistrationListener {
    void notify ( String p0, String p1 );
}
