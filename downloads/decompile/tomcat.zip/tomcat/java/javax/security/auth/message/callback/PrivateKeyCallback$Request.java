package javax.security.auth.message.callback;
public interface Request {
}
