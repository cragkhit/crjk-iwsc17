package javax.mail;
public class PasswordAuthentication {
    public PasswordAuthentication ( final String user, final String password ) {
    }
}
