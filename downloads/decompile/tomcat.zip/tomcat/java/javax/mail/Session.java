package javax.mail;
import java.util.Properties;
public class Session {
    public static Session getInstance ( final Properties props, final Authenticator auth ) {
        return null;
    }
    public static Session getInstance ( final Properties props ) {
        return null;
    }
}
