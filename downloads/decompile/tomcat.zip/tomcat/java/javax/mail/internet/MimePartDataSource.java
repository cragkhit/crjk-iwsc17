package javax.mail.internet;
public class MimePartDataSource {
    public MimePartDataSource ( final MimePart part ) {
    }
}
