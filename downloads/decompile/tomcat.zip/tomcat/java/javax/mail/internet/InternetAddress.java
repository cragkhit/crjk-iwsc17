package javax.mail.internet;
public class InternetAddress {
    public InternetAddress ( final String from ) {
    }
}
