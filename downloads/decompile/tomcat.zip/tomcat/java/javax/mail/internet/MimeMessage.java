package javax.mail.internet;
import javax.mail.Session;
public class MimeMessage implements MimePart {
    public MimeMessage ( final Session session ) {
    }
    public void setFrom ( final InternetAddress from ) {
    }
    public void setSubject ( final String subject ) {
    }
}
