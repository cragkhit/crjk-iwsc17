package org.apache.catalina.connector;
private interface SpecialAttributeAdapter {
    Object get ( Request p0, String p1 );
    void set ( Request p0, String p1, Object p2 );
}
