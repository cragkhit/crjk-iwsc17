package org.apache.catalina.authenticator;
static class AuthenticatorBase$1 {}
