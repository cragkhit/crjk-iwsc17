package org.apache.catalina;
public interface ContainerListener {
    void containerEvent ( ContainerEvent p0 );
}
