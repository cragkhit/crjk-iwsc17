package org.apache.catalina.connector;
private static class RecycleRequiredException extends Exception {
    private static final long serialVersionUID = 1L;
}
