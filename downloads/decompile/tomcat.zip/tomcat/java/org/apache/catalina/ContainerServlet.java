package org.apache.catalina;
public interface ContainerServlet {
    Wrapper getWrapper();
    void setWrapper ( Wrapper p0 );
}
