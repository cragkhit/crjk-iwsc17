package org.apache.catalina.core;
private static class DebugException extends Exception {
    private static final long serialVersionUID = 1L;
}
