package org.apache.catalina.authenticator.jaspic;
static class AuthConfigFactoryImpl$1 {}
