package org.junit.experimental.theories;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Retention ( RetentionPolicy.RUNTIME )
@Target ( {FIELD, METHOD} )
public @interface DataPoint {
String[] value() default {};
Class<? extends Throwable>[] ignoredExceptions() default {};
}
