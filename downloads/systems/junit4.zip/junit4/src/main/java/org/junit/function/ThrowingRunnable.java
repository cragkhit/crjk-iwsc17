package org.junit.function;
public interface ThrowingRunnable {
    void run() throws Throwable;
}
