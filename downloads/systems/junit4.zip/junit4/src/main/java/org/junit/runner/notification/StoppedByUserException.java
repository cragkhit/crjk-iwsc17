package org.junit.runner.notification;
public class StoppedByUserException extends RuntimeException {
    private static final long serialVersionUID = 1L;
}
