package org.junit.internal.management;
import java.util.List;
public interface RuntimeMXBean {
    List<String> getInputArguments();
}
