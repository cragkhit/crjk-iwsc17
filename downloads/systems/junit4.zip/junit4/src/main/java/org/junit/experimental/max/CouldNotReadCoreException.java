package org.junit.experimental.max;
public class CouldNotReadCoreException extends Exception {
    private static final long serialVersionUID = 1L;
    public CouldNotReadCoreException ( Throwable e ) {
        super ( e );
    }
}
