package org.junit.runner;
public interface Describable {
    Description getDescription();
}
