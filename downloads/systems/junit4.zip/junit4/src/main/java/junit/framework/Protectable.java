package junit.framework;
public interface Protectable {
    public abstract void protect() throws Throwable;
}
