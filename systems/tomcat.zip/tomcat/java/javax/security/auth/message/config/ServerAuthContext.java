package javax.security.auth.message.config;
import javax.security.auth.message.ServerAuth;
public interface ServerAuthContext extends ServerAuth {
}
