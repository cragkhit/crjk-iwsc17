package javax.security.auth.message.config;
import javax.security.auth.message.ClientAuth;
public interface ClientAuthContext extends ClientAuth {
}
