package javax.security.auth.message.config;
public interface RegistrationListener {
    void notify ( String layer, String appContext );
}
