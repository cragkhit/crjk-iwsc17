package javax.persistence;
public enum SynchronizationType {
    SYNCHRONIZED,
    UNSYNCHRONIZED
}
