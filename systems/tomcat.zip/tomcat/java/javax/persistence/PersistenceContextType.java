package javax.persistence;
public enum PersistenceContextType {
    TRANSACTION,
    EXTENDED
}
