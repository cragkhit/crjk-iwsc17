package javax.websocket;
public interface SendHandler {
    void onResult ( SendResult result );
}
