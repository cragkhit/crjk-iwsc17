package javax.el;
public interface ELContextListener extends java.util.EventListener {
    public void contextCreated ( ELContextEvent event );
}
