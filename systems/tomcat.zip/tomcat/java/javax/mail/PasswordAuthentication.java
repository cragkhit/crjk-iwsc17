package javax.mail;
@SuppressWarnings ( "unused" )
public class PasswordAuthentication {
    public PasswordAuthentication ( String user, String password ) {
    }
}
