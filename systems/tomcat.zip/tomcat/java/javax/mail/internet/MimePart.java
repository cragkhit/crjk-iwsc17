package javax.mail.internet;
public interface MimePart {
}
