package javax.mail.internet;
@SuppressWarnings ( "unused" )
public class MimePartDataSource {
    public MimePartDataSource ( MimePart part ) {
    }
}
