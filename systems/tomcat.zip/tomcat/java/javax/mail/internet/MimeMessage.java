package javax.mail.internet;
import javax.mail.Session;
@SuppressWarnings ( "unused" )
public class MimeMessage implements MimePart {
    public MimeMessage ( Session session ) {
    }
    public void setFrom ( InternetAddress from ) {
    }
    public void setSubject ( String subject ) {
    }
}
