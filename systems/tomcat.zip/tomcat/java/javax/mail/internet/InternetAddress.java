package javax.mail.internet;
@SuppressWarnings ( "unused" )
public class InternetAddress {
    public InternetAddress ( String from ) {
    }
}
