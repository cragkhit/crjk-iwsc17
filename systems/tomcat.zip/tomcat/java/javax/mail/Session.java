package javax.mail;
import java.util.Properties;
@SuppressWarnings ( "unused" )
public class Session {
    public static Session getInstance ( Properties props, Authenticator auth ) {
        return null;
    }
    public static Session getInstance ( Properties props ) {
        return null;
    }
}
