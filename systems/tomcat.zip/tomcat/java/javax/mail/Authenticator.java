package javax.mail;
public class Authenticator {
    protected PasswordAuthentication getPasswordAuthentication() {
        return null;
    }
}
