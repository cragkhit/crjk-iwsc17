package javax.servlet.jsp.tagext;
public interface JspIdConsumer {
    public void setJspId ( String jspId );
}
