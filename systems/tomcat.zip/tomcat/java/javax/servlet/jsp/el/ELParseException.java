package javax.servlet.jsp.el;
@SuppressWarnings ( "dep-ann" )
public class ELParseException extends ELException {
    private static final long serialVersionUID = 1L;
    public ELParseException () {
        super ();
    }
    public ELParseException ( String pMessage ) {
        super ( pMessage );
    }
}
