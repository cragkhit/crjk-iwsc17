package javax.servlet.jsp.el;
@SuppressWarnings ( "dep-ann" )
public interface FunctionMapper {
    public java.lang.reflect.Method resolveFunction ( String prefix,
            String localName );
}
