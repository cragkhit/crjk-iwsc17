package javax.servlet.descriptor;
public interface TaglibDescriptor {
    public String getTaglibURI();
    public String getTaglibLocation();
}
