package javax.servlet;
@Deprecated
public interface SingleThreadModel {
}
