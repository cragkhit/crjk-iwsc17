package org.apache.catalina;
public interface ContainerListener {
    public void containerEvent ( ContainerEvent event );
}
