package org.apache.catalina.ha.backend;
import java.net.InetAddress;
public class Proxy {
    public InetAddress address = null;
    public int port = 80;
}
