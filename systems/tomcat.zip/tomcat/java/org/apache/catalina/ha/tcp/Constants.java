package org.apache.catalina.ha.tcp;
public class Constants {
    public static final String Package = "org.apache.catalina.ha.tcp";
}
