package org.apache.catalina.ha.session;
import java.io.Serializable;
import org.apache.catalina.SessionListener;
public interface ReplicatedSessionListener extends SessionListener, Serializable {
}
