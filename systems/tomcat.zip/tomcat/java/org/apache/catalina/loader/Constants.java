package org.apache.catalina.loader;
public class Constants {
    public static final String Package = "org.apache.catalina.loader";
}
