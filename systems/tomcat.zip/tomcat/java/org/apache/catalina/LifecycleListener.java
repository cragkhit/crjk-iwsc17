package org.apache.catalina;
public interface LifecycleListener {
    public void lifecycleEvent ( LifecycleEvent event );
}
