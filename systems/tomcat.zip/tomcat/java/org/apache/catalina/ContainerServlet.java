package org.apache.catalina;
public interface ContainerServlet {
    public Wrapper getWrapper();
    public void setWrapper ( Wrapper wrapper );
}
