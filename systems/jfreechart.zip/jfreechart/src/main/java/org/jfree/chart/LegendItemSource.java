

package org.jfree.chart;


public interface LegendItemSource {


    public LegendItemCollection getLegendItems();

}
