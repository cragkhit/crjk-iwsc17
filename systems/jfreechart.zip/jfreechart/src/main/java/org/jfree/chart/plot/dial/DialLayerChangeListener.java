package org.jfree.chart.plot.dial;
import java.util.EventListener;
public interface DialLayerChangeListener extends EventListener {
    public void dialLayerChanged ( DialLayerChangeEvent event );
}
