

package org.jfree.chart.event;

import java.util.EventListener;


public interface RendererChangeListener extends EventListener {


    public void rendererChanged ( RendererChangeEvent event );

}
