

package org.jfree.chart.plot;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.Range;


public interface ValueAxisPlot {


    public Range getDataRange ( ValueAxis axis );

}
