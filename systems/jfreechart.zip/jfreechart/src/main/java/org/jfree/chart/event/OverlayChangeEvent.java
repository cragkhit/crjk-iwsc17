package org.jfree.chart.event;
import java.util.EventObject;
import org.jfree.chart.panel.Overlay;
public class OverlayChangeEvent extends EventObject {
    public OverlayChangeEvent ( Object source ) {
        super ( source );
    }
}
