

package org.jfree.chart.imagemap;


public interface ToolTipTagFragmentGenerator {


    public String generateToolTipFragment ( String toolTipText );

}
