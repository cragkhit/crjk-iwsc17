

package org.jfree.chart.event;

import java.util.EventListener;


public interface TitleChangeListener extends EventListener {


    public void titleChanged ( TitleChangeEvent event );

}
