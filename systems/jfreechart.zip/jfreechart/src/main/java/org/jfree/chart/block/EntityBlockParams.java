

package org.jfree.chart.block;


public interface EntityBlockParams {


    public boolean getGenerateEntities();

}
