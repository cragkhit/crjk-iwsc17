package org.jfree.chart.annotations;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.XYPlot;
public interface XYAnnotation extends Annotation {
    public void draw ( Graphics2D g2, XYPlot plot, Rectangle2D dataArea,
                       ValueAxis domainAxis, ValueAxis rangeAxis,
                       int rendererIndex, PlotRenderingInfo info );
}
