

package org.jfree.chart.plot;

import org.jfree.chart.renderer.xy.XYItemRenderer;


public class XYCrosshairState extends CrosshairState {


    public XYCrosshairState() {

    }

}
