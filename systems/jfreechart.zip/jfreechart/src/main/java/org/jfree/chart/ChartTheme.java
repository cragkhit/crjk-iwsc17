

package org.jfree.chart;


public interface ChartTheme {


    public void apply ( JFreeChart chart );

}
