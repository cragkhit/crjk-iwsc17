

package org.jfree.chart.encoders;


public interface ImageFormat {


    public static String PNG = "png";


    public static String JPEG = "jpeg";


    public static String GIF = "gif";

}
