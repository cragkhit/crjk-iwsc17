

package org.jfree.chart.editor;

import javax.swing.JComponent;

import org.jfree.chart.JFreeChart;


public interface ChartEditor {


    public void updateChart ( JFreeChart chart );

}
