

package org.jfree.chart.renderer.xy;

import java.io.Serializable;


public class DefaultXYItemRenderer extends XYLineAndShapeRenderer
    implements Serializable {


    static final long serialVersionUID = 3450423530996888074L;


}
