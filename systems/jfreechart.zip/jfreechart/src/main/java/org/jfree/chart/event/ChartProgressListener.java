

package org.jfree.chart.event;

import java.util.EventListener;


public interface ChartProgressListener extends EventListener {


    public void chartProgress ( ChartProgressEvent event );

}
