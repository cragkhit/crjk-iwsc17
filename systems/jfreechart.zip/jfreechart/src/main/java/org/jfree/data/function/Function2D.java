

package org.jfree.data.function;


public interface Function2D {


    public double getValue ( double x );

}
