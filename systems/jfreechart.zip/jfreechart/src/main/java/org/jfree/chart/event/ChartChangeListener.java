

package org.jfree.chart.event;

import java.util.EventListener;


public interface ChartChangeListener extends EventListener {


    public void chartChanged ( ChartChangeEvent event );

}
