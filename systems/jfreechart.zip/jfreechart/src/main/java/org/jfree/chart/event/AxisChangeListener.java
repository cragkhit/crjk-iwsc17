

package org.jfree.chart.event;

import java.util.EventListener;


public interface AxisChangeListener extends EventListener {


    public void axisChanged ( AxisChangeEvent event );

}
