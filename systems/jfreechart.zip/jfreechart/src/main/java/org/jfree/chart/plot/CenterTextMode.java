package org.jfree.chart.plot;
public enum CenterTextMode {
    FIXED,
    VALUE,
    NONE
}
