

package org.jfree.chart.event;

import java.util.EventListener;


public interface PlotChangeListener extends EventListener {


    public void plotChanged ( PlotChangeEvent event );

}
