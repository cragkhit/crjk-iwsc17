

package org.jfree.chart.renderer;


public class NotOutlierException extends Exception {


    public NotOutlierException ( String message ) {
        super ( message );
    }

}
