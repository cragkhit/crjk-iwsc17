

package org.jfree.chart.plot;

import org.jfree.chart.renderer.xy.XYBlockRenderer;
import org.jfree.data.Range;


public interface ContourValuePlot {


    public Range getContourDataRange();

}
