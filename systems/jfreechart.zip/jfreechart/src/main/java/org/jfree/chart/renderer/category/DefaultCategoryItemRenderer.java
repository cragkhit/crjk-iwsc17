

package org.jfree.chart.renderer.category;

import java.io.Serializable;

import org.jfree.chart.plot.CategoryPlot;


public class DefaultCategoryItemRenderer extends LineAndShapeRenderer
    implements Serializable {


    private static final long serialVersionUID = -7793786349384231896L;


}
