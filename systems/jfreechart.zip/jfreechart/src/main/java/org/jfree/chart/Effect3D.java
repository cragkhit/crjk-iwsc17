

package org.jfree.chart;


public interface Effect3D {


    public double getXOffset();


    public double getYOffset();
}
