

package org.jfree.data.category;

import org.jfree.data.KeyedValues2D;
import org.jfree.data.general.Dataset;


public interface CategoryDataset extends KeyedValues2D, Dataset {


}
